//package com.dailycodework.excel2database.util;
//
//public class GradeUtil {
//    public static int getGradePoint(String grade) {
//        return switch (grade.toUpperCase()) {
//            case "O" -> 10;
//            case "A+" -> 9;
//            case "A" -> 8;
//            case "B+" -> 7;
//            case "B" -> 6;
//            case "C" -> 5;
//            case "F" -> 0;
//            default -> 0;
//        };
//    }
//}
////