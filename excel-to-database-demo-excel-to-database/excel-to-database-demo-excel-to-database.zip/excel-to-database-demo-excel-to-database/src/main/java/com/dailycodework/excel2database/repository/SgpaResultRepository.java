//package com.dailycodework.excel2database.repository;
//
//import com.dailycodework.excel2database.domain.SgpaResult;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.Optional;
//
//public interface SgpaResultRepository extends JpaRepository<SgpaResult, Long> {
//    Optional<SgpaResult> findByHtno(String htno);
//}
////